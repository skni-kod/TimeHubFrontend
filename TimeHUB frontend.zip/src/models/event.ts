export default interface event{
    id: number,
    zawartosc: string,
    data_rozpoczecia: string,
    data_zakonczenia: string,
    //allDay: boolean
}